# Assets List
| File | Use | Size/format |
|---|---|---|
| public/assets/logo.svg | Top bar, favicon source | SVG |
| public/assets/og.jpg | Social share image | 1200x630 |
| public/assets/work/p1.webp ... p4.webp | Work cards and pillar proof | 16:10, <150 KB |
| public/assets/fonts/VT323-Regular.woff2 | Display/UI font (self-host optional) | woff2 |
| public/assets/avatar-assistant.svg | Assistant icon | SVG |
