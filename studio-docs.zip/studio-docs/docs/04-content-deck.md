# 04-content-deck — ALL site copy
This file is the source of truth. content/site.json must mirror it.

## Global
- Studio name: {{STUDIO_NAME}}
- Nav: Home, Services, Work, Process, Pricing, Contact
- Primary button: "Book a call" · Secondary: "See our work"

## Home
- Eyebrow: "> SYSTEM ONLINE"
- H1: "Ideas don't ship themselves."
- Sub: "We design and build digital products, from first sketch to live launch."

## Services

### Pillar A — Design & Experience
Tagline: "Clear, beautiful, and made to be used."
01 Product Design — Flows and screens built around real user needs.
02 Brand Identity — A look and voice that people remember.
03 Websites & Launch Pages — Fast, sharp pages that explain and convert.
04 Interactive Prototypes — Clickable ideas you can test before you build.
05 AI-Interface Design — Chat, copilots and agent screens people can trust.
06 Design Systems — One toolkit so every screen stays consistent.

### Pillar B — Engineering & Launch
Tagline: "Built properly. Shipped quickly."
01 Web Apps — Dashboards, portals and SaaS products.
02 Mobile Apps — iOS and Android apps with native feel.
03 MVP Builds — The smallest real product that proves your idea.
04 AI Features & Agents — Practical AI added where it saves time.
05 Cloud & DevOps — Hosting, pipelines and monitoring that just work.
06 Code Rescue — We stabilise and tidy products built in a rush.

Proof under each pillar: two project thumbnails (see 05).

## Process (4 steps)
1. Discover — "We learn your users, goals and limits." (Week 1)
2. Design — "We shape flows and visuals, then test them." (Weeks 2–3)
3. Build — "We code in short cycles you can see." (Weeks 3–8)
4. Launch — "We ship, measure and keep improving." (Week 8+)

## Pricing (ballpark, edit to real numbers)
- Starter — Landing page or brand sprint — from {{PRICE_1}} — 1–2 weeks
- Build — MVP or app — from {{PRICE_2}} — 6–10 weeks
- Partner — Ongoing product team — from {{PRICE_3}}/month
Note: "Every project is scoped after a free 30-minute call."

## FAQ (used by the assistant)
- How long does an MVP take? Typically 6–10 weeks.
- Do you work with early-stage startups? Yes, that is our main audience.
- Who owns the code and designs? You do, fully, at final payment.
- Can you fix an existing product? Yes, see Code Rescue.

## Contact
- H2: "Let's build the thing."
- Fields (if form): Name, Email, "What are you building?", Budget range (select)
- Success: "Got it. We'll reply within one working day."
- Error: "Something broke. Email us at {{EMAIL}}."

## Microcopy
- Boot lines: see 07-interaction-spec.md
- Command bar placeholder: "type a command, or press ? for help"
- 404 / unknown command: "UNKNOWN COMMAND. TRY: help"
