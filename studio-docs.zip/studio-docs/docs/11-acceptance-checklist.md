# 11 — Acceptance Checklist
Mark each PASS/FAIL. Do not mark a task complete with any FAIL.

## Layout
- [ ] No scrollbar and no scrolling at 1440x900, 1280x720, 768x1024, 390x844, 360x640
- [ ] No content cut off in any panel at those sizes
- [ ] Orientation change on mobile does not break layout

## Story and content
- [ ] Every panel text matches 04-content-deck.md
- [ ] Story beats appear in the order of 03-story-script.md
- [ ] All 12 services visible under the correct pillar

## Interaction
- [ ] Boot plays once, skippable, skipped with reduced motion
- [ ] Keys 1–6, arrows and Ctrl/Cmd+K work
- [ ] Process blueprint works by mouse, keyboard and touch
- [ ] Case-file overlay closes with Esc and returns focus
- [ ] Theme toggle works and persists

## Command bar (test inputs)
- [ ] services, work, process, pricing, contact, help, pick, book, theme, mvp
- [ ] Unknown input shows suggestions

## Quality
- [ ] Lighthouse: Performance 90+, Accessibility 95+, SEO 95+
- [ ] First load JS under 150 KB gzip
- [ ] Keyboard-only run through the whole site possible
- [ ] Contrast 4.5:1 in both themes
- [ ] No console errors; npm run lint and build pass
