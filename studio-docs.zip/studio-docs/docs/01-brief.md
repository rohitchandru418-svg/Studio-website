# 01 — Brief

## Studio
- Name: {{STUDIO_NAME}}
- Tagline: {{TAGLINE}}
- Location / time zone: {{LOCATION}}
- Contact: {{EMAIL}} · {{PHONE}} · {{BOOKING_LINK}}

## What we do
Product design and software development for startups and teams, from idea to launched product.

## Audience
1. Founders with an idea who need an MVP built fast.
2. Startups adding AI features to an existing product.
3. Teams whose current product needs a redesign or a rescue.

## Promise (one line)
{{PROMISE_LINE}}   <!-- Example: "We turn product ideas into shipped software, fast and without the noise." -->

## Tone of voice
Confident, plain, a little playful. Short sentences. No jargon walls. Terminal-style labels are allowed (e.g. "> LOADING PROCESS").

## References and what to take
| Reference | Take | Do not take |
|---|---|---|
| Off Menu (services page) | Two pillars, numbered service lists, proof thumbnail per pillar, assistant with quick prompts | Their wording, names or images |
| Heron AI | Boot sequence with numbered lines, interactive demo you drag or click, problem → solution story | Their sketch artwork |
| Fumadocs | Command-bar navigation (Ctrl/Cmd+K), layered "stack" diagram, numbers as proof | Docs-site layout |
| Our own idea | One screen, no scrolling, retro CRT, futuristic motion | — |

## Success looks like
A visitor understands what we do in 10 seconds, finds services/pricing in two clicks or one typed command, and books a call.
