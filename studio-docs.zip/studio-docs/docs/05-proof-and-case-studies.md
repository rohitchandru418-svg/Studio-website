# 05 — Proof and Case Studies

## Projects (replace with real ones)
| # | Name | Type | One-line outcome | Metric | Thumbnail |
|---|---|---|---|---|---|
| 1 | {{PROJECT_1}} | Brand + web | {{OUTCOME_1}} | {{METRIC_1}} | public/assets/work/p1.webp |
| 2 | {{PROJECT_2}} | Web app | {{OUTCOME_2}} | {{METRIC_2}} | public/assets/work/p2.webp |
| 3 | {{PROJECT_3}} | Mobile app | {{OUTCOME_3}} | {{METRIC_3}} | public/assets/work/p3.webp |
| 4 | {{PROJECT_4}} | AI product | {{OUTCOME_4}} | {{METRIC_4}} | public/assets/work/p4.webp |

Placement: projects 1–2 under the Design pillar, 3–4 under the Development pillar, all four in the Work panel.

## Stats strip (footer)
- Projects shipped: {{N}}
- Years active: {{N}}
- Clients: {{N}}

## Quotes (optional, max 3)
"{{QUOTE}}" — {{NAME}}, {{ROLE}}, {{COMPANY}}

## Rules
- Only use real numbers and written permission for names and logos.
- Thumbnails: 16:10, WebP, under 150 KB each.
