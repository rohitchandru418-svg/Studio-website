# 03 — Story Script

Story spine: Hook → Problem → Turning point → Solution → Proof → Call to action.
Each beat is one screen state. Replace {{...}} values with real ones.

## Beat 1 — Hook (Home)
- Headline: "Ideas don't ship themselves."
- Support: "{{STUDIO_NAME}} designs and builds products people actually use."
- Buttons: [SEE WHAT WE DO] [BOOK A CALL]

## Beat 2 — Problem (Home, press any key or click "Why us?")
Four numbered pain points, revealed one by one:
- [01] Slow: months of meetings before anything real exists.
- [02] Scattered: design in one place, code in another, nobody owns the result.
- [03] Fragile: quick builds that break the moment users arrive.
- [04] Noisy: tools, jargon and updates, but no clear progress.

## Beat 3 — Turning point
Line: "What if one small team did the thinking, the design and the building?"

## Beat 4 — Solution (Services + Process)
- Services: two pillars, Design and Development (see 04-content-deck.md).
- Process: Discover → Design → Build → Launch (see Process panel).

## Beat 5 — Proof (Work)
Four projects, one line of outcome each (see 05-proof-and-case-studies.md).

## Beat 6 — Call to action (Pricing → Contact)
- Headline: "Let's build the thing."
- Support: "Tell us the idea. We'll reply within one working day."
- Button: [BOOK A CALL]

## Pacing rules
- One idea per screen. Max 25 words of body text per panel state.
- Every beat ends with a clear next action.
