# 02 — Sitemap and Flow

There is one URL (/). "Pages" are panels inside one fixed screen. Optional deep links use hash: #services, #work, #process, #pricing, #contact.

## Panels
| # | Panel | Goal | Primary next step |
|---|---|---|---|
| 00 | Boot | Set mood, load the experience (max 3 s, skippable) | Home |
| 01 | Home | Hook + promise | Services |
| 02 | Services | Show the two pillars and what we do | Work or Pricing |
| 03 | Work | Proof: 4 projects | Pricing |
| 04 | Process | How we work in 4 steps (interactive blueprint) | Pricing |
| 05 | Pricing | Ballpark ranges, remove fear | Contact |
| 06 | Contact | Book a call, send a brief | — |

## Global UI (always visible)
- Top bar: studio name, live clock, theme toggle.
- Left menu (bottom bar on mobile): panels 01–06.
- Bottom: command bar + assistant prompts.
- Footer strip: proof numbers (projects shipped, years, clients).

## Flow
Boot → Home → Services → (Work | Process) → Pricing → Contact
Shortcuts: keys 1–6 jump to a panel; Ctrl/Cmd+K focuses command bar; Esc closes overlays.

## Transitions between panels
Out: 150 ms glitch-fade. In: 300 ms stepped reveal. Update URL hash. Never scroll.
