# 08 — Assistant / Command Bar Spec

Name: {{ASSISTANT_NAME}} (e.g. "Remi"-style helper; pick your own name)
Phase 1 = rule-based command bar (no API). Phase 2 (optional) = AI-backed answers using the FAQ in 04-content-deck.md.

## Quick prompts (buttons shown above the bar)
- Help me pick a service
- How do we work together?
- Ballpark on pricing

## Commands
| Input | Result |
|---|---|
| home, services, work, process, pricing, contact | Go to panel |
| help or ? | List commands |
| pick | Start 3-question service picker |
| pricing | Go to Pricing and show tiers |
| book | Go to Contact |
| theme | Toggle theme |
| mvp, app, web, ai, brand, design, rescue | Jump to Services and highlight match |
| anything else | "UNKNOWN COMMAND. TRY: help" plus 3 closest suggestions |

## Service picker (3 questions, tappable)
1. What do you need? [An idea built] [A redesign] [AI added] [A rescue]
2. Stage? [Just an idea] [Prototype exists] [Live product]
3. Timeline? [ASAP] [1–3 months] [Flexible]
Result: recommend 1–2 services and a pricing tier, with a Book a call button.

## Behaviour rules
- Replies appear typed at 20 ms per character, max 40 words.
- Always end with a next action button.
- Never invent prices or promises; use only 04-content-deck.md.
- History: last 5 commands via arrow up/down.
