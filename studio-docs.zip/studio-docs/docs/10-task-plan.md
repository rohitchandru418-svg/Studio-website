# 10 — Task Plan
Do one task at a time. Each has a "Done when" line. Check docs/11 after each.

1. Scaffold — Create Next.js + Tailwind project, folder structure, content/site.json from 04. Done when: npm run dev and build pass; page shows studio name.
2. Shell — Fixed full-screen grid: header, nav, main, footer, command bar slot. Done when: no scrollbar at 1280x720 and 390x844.
3. Design tokens — CSS variables, fonts, dark/light theme toggle. Done when: both themes work and persist.
4. Background FX — Grid canvas, scanlines, vignette, cursor glow. Done when: 60 fps, pauses in hidden tab, off in reduced motion.
5. Boot — Boot screen per 07. Done when: skippable, shows once per session.
6. Panel system — Hash routing, keys 1–6, transitions. Done when: deep links and back button work.
7. Home panel — Typewriter + problem reveal per 03. Done when: matches script.
8. Services panel — Two pillars, numbered lists, hover details, proof thumbs. Done when: all 12 services render from JSON.
9. Process panel — Interactive blueprint with drag/keys/swipe. Done when: works by mouse, keyboard and touch.
10. Work panel — 4 cards + case-file overlay. Done when: Esc closes, focus returns.
11. Pricing panel — Three tiers + toggle. Done when: copy matches 04.
12. Contact panel — Booking link/form + success state. Done when: submits or opens mail client.
13. Command bar + assistant — Commands and picker per 08. Done when: all listed commands pass.
14. Footer stats and top bar — Clock, stats strip.
15. Mobile pass — Bottom tabs, swipe, tap states. Done when: all panels usable at 390x844.
16. Accessibility + SEO pass — Per 09.
17. Performance pass — Meet budget; Lighthouse 90+.
18. Deploy — Production build live; share URL.
