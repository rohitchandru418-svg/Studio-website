# 07 — Interaction Spec
Format: Trigger → What happens → Duration.

## Boot (first visit only, skippable with any key or click)
Trigger: page load → lines type in, one every 170 ms:
```
{{STUDIO_NAME}} OS v1.0
001 INITIALIZE CORE SYSTEM ... OK
002 LOAD DESIGN MODULES ...... OK
003 LOAD ENGINEERING MODULES . OK
004 SYNC IDEAS ............... OK
005 READY
```
Then fade out 500 ms → Home. Reduced motion: skip entirely. Remember with sessionStorage.

## Panel switching
Click nav, key 1–6, arrow up/down, hash change → current panel glitch-fades 150 ms, next steps in 300 ms. Update hash. Focus moves to panel heading.

## Home
- Headline types out 28 ms per character with blinking block cursor.
- Press any key or click "Why us?" → problem points [01]–[04] appear one per 600 ms.

## Services
- Two columns (stacked tabs on mobile). Hover/focus a service → right side shows its one-line description and a small animated glyph; row shifts 6 px.
- Click a service → assistant opens prefilled: "Tell me about {service}".

## Process — interactive blueprint (centrepiece)
- A line-drawn blueprint with 4 nodes (Discover, Design, Build, Launch).
- Drag a slider/handle (or arrow keys) along the line: the active node lights up, text and timeline update, a progress bar fills.
- Mobile: swipe horizontally.

## Work
- 4 cards in a grid. Hover = lift + glow. Click = case-file overlay (image, outcome, metric, Close with Esc).

## Pricing
- Three tiers as cards. Toggle "Project / Monthly" changes displayed copy.

## Contact
- Form or booking button. Success replaces form with confirmation message.

## Global
- Pointer glow follows cursor; grid shifts toward pointer.
- Ctrl/Cmd+K focuses command bar; ? shows help overlay of shortcuts.
- Theme toggle swaps dark/light with 200 ms colour transition.
- Sound: none by default (optional toggle later).

## Mobile
- Menu becomes a bottom tab bar. Hover effects become tap states. Panels may use internal paging (swipe), never page scroll.
