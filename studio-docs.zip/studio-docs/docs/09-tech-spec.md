# 09 — Tech Spec

## Stack
Next.js (App Router), TypeScript, Tailwind CSS. Host on Vercel or any Node/static host.

## Structure
app/layout.tsx, app/page.tsx, components/, content/site.json, public/assets/, lib/commands.ts, lib/useHashPanel.ts

## Rendering
- Single page; panels are client components switched by state + hash.
- Content loaded from content/site.json at build time.
- Background grid: one canvas, requestAnimationFrame, paused when tab hidden.

## Layout rule
html, body { height: 100dvh; overflow: hidden }. Use dvh not vh for mobile browsers.

## Performance budget
- First load JS under 150 KB gzip.
- LCP under 2 s on mid-range mobile.
- Images WebP, lazy-load case-file images.

## Accessibility
- Landmarks: header, nav, main, footer. Panels have role="region" and aria-labelledby.
- Command bar has a label; assistant replies use aria-live="polite".
- Full keyboard path; focus trap in overlays.
- Reduced motion honoured.

## SEO (important because there is one page)
- Real text for all panels in the DOM (hidden panels use hidden attribute, not removed), meta title/description, Open Graph image, sitemap.xml, robots.txt, JSON-LD Organization.
- Add a static, crawlable "/services" and "/work" route later if needed.

## Contact handling
Phase 1: mailto and booking link. Phase 2: API route sending email (Resend or similar) with spam protection.

## Analytics
Privacy-friendly (Plausible or similar). Events: panel_view, command_used, cta_click, form_submit.
