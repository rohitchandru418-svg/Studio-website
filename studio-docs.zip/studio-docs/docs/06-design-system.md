# 06 — Design System

## Colour tokens
| Token | Dark (default) | Light ("paper") |
|---|---|---|
| --bg | #07090f | #f1e6c8 |
| --fg | #ffb454 | #5a2e00 |
| --accent | #39ffc8 | #006b52 |
| --dim | #8a6a3a | #8a7048 |
| --panel | rgba(255,180,84,.06) | rgba(90,46,0,.07) |
| --line | rgba(255,180,84,.35) | rgba(90,46,0,.4) |
Use CSS variables. Theme switches via data-theme and prefers-color-scheme.

## Type
- Display and UI: "VT323", fallback ui-monospace, Menlo, Consolas, monospace.
- Sizes: H1 clamp(34px, 6.5vw, 76px); H2 32px; body 21px (18px mobile); label 16px.
- Line height: 1.15 body, 0.95 display. All headings uppercase optional.

## Spacing and shape
- Base unit 8 px. Panel padding 22–26 px (14 px mobile).
- Borders 1 px solid var(--line). No rounded corners (0 radius) except the glow.

## Effects
- Scanlines: repeating 1px line every 3px, 18% black, multiply blend.
- Vignette: radial gradient to 45% black at edges.
- Perspective grid canvas behind everything, shifts toward the pointer by 15%.
- Cursor glow: 360 px radial gradient in --accent at 14% opacity.
- Text glow: text-shadow 0 0 8–14px var(--accent) on headings and active items.

## Components
- Button: 1px border, uppercase, hover = filled with --accent, text --bg.
- Card: panel background + border; hover lifts 4 px, rotates -0.6deg, accent glow.
- Nav item: "01 HOME ▸"; active/hover shifts 6 px right, accent colour.
- Chip/link: bordered, hover filled.
- Command bar: prompt "C:\>", accent caret, dashed top border.
- Labels: bracketed numbers like [01].

## Accessibility
Contrast at least 4.5:1 for body text in both themes. Visible focus ring: 2px solid var(--accent).
