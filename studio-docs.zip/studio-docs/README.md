# Studio website — OpenHands spec pack
1. Search/replace every {{PLACEHOLDER}} with real values (start with 01-brief and 04-content-deck).
2. Put this folder in your repo root (AGENTS.md at root, the rest in /docs).
3. In OpenHands, give one task at a time from docs/10-task-plan.md.
4. After each task, run docs/11-acceptance-checklist.md.
