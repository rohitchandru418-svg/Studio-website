# AGENTS.md — Standing rules for OpenHands

## Project
A single-screen, no-scroll, story-driven website for {{STUDIO_NAME}}, a product development studio. Retro CRT look, futuristic interaction.

## Read first (in order)
docs/01-brief.md → 02-sitemap-and-flow.md → 03-story-script.md → 04-content-deck.md → 06-design-system.md → 07-interaction-spec.md → 08-assistant-spec.md → 09-tech-spec.md

## Stack
Next.js (App Router) + TypeScript + Tailwind CSS. Animations: CSS first, Framer Motion only where CSS cannot do it. No other UI libraries without asking.

## Folder structure
- app/            routes and layout
- components/     Boot, Shell, Nav, Panel*, CommandBar, Assistant, Blueprint
- content/site.json   ALL copy lives here. Never hard-code text in components.
- public/assets/  images, fonts
- docs/           specs (do not edit unless told)

## Hard rules
1. The page must NEVER scroll (html, body: overflow hidden, height 100dvh). Panels swap; inside a panel, content must fit or paginate.
2. All copy comes from content/site.json, which mirrors docs/04-content-deck.md.
3. Keyboard accessible: every panel, the command bar and the assistant.
4. Respect prefers-reduced-motion: skip boot animation and heavy effects.
5. Mobile (390x844) is a first-class target, not an afterthought.
6. No external network calls at runtime except fonts.
7. Do not copy wording from other studios' sites. Use the copy in the content deck.

## Workflow
Work on ONE task at a time from docs/10-task-plan.md. When done, run the checks in docs/11-acceptance-checklist.md for that task, then stop and report.

## Commands
- npm run dev
- npm run build
- npm run lint
